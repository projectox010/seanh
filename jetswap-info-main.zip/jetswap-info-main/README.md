# Pancake History

Check it out live: [https://pancakeswap.info/](https://pancakeswap.info/).

### To Start Development

###### Installing dependencies
```bash
yarn
```

###### Running locally
```bash
yarn start
```
